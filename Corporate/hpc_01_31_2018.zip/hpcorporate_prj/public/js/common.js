function getBaseUrl(str)
{
    return 'http://www.hpcorporate.dev/' + str;
}