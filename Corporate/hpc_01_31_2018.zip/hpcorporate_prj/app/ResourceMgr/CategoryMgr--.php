<?php

namespace App\ResourceMgr;

use Illuminate\Http\Request;
use App\Lib\HpStdResponse;
use Illuminate\Support\Facades\DB;
use App\Lib\hp_utils;
use Illuminate\Support\Facades\Validator;

class CategoryMgr {

public function getAll()
{
	return hp_constant;
	# code...
}
}