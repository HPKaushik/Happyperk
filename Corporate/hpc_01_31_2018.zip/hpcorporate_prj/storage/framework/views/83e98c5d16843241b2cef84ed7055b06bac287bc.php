<?php $__env->startSection('page_title'); ?>
All Company
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header" data-background-color="purple">
                    <h4 class="title">All Transactions</h4>
                </div>
              
                <div class="card-content">
                    <div class="fresh-datatables ajax-table" id='anouncement_list'>
                        <?php echo $__env->make('profile.partials.transactions.ajax_list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div> 
                </div> 
            </div>
        </div> 
    </div> 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>