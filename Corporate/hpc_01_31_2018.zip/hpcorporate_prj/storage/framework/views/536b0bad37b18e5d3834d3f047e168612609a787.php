<?php $__env->startSection('page_title'); ?>
All Announcements
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header" data-background-color="purple">
                    <h4 class="title">All Announcements</h4>
                     <div class="alert alert-yellow  pull-right" data-notify="container">
                        <a href='<?php echo e(URL::route('create-announcement')); ?>' class="">Add Announcement</a> 
                    </div>
                </div>

                <div class="card-content">
                    <div class="ajax-table" id='_anouncement_list'>
                        <?php echo $__env->make('announcements.inc.ajax_list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div> 
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>