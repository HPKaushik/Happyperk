<?php $__env->startSection('page_title'); ?>
Add Designations
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid designation_company">
    <div class="col-md-12">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header" data-background-color="purple">
                    <h4 class="title">All Designations</h4>
                    <p class="category">Drag and drop designations from the below list</p>
                </div>
                <div class="card-content">
                    <ul class="nav drag-here" id="_all_designations_list" ondrop="drop(event)" >
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li draggable="true" ondragstart="drag(event)" id='pre_design_<?php echo e($desig->id); ?>'>
                            <input type="hidden" name="designations[]" value="<?php echo e($desig->id); ?>"/>
                            <?php echo e($desig->name); ?>

                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <?php echo Form::open(array('route' => ['store-designation'],'method'=>'POST')); ?>

            <div class="card">
                <div class="card-header" data-background-color="purple">
                    <h4 class="title">Company Designation</h4>
                    <div class="alert alert-yellow  pull-right p0" data-notify="container">
                        <button type="submit" class="btn btn-yellow m0"><i class="material-icons">save</i>Save</button>
                    </div>
                </div>
                <div class="card-content">
                    <ul id="_company_designation_list" class="nav drop-here" ondragover="allowDrop(event)" ondrop="drop(event)">
                        <?php $__currentLoopData = $data->company_designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cdesig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li draggable="true" ondragstart="drag(event)" id='pre_design_<?php echo e($cdesig->id); ?>'>
                            <input type="hidden" name="designations[]" value="<?php echo e($cdesig->id); ?>"/>
                            <?php echo e($cdesig->name); ?>

                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('component_specific_js'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/designations/index.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>