<?php if($data->employees->total() > 0): ?>
<table class="table hover-table table-hover" >
    <thead >
        <tr>
            <th><b>Select</b></th>
            <th><b>Emp Code</b></th>
            <th><b>Name</b></th>
            <th><b>Department</b></th>
            <th><b>Created On</b></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data->employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <div class="radio">
                    <label>
                        <input type="radio" name="employee" class="move_on_select" value="<?php echo e($emp->employee_id); ?>"
                               <?php if(isset($data->award)): ?>
                               <?php echo e($emp->employee_id == $data->award->employee ? 'checked':''); ?>

                               <?php endif; ?>
                               ><span class="circle"></span><span class="check"></span>
                    </label>
                </div>
            </td>
            <td >
                <?php echo e($emp->emp_code ? $emp->emp_code : '-'); ?>

            </td>
            <td><?php echo e($emp->first_name); ?>  <?php echo e($emp->last_name); ?></td>
            <td><?php echo e($emp->department_name); ?></td>
            <td><?php echo e(date('d M y', strtotime($emp->created_at))); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="pagination">
    <?php echo e($data->employees->appends(Input::except('page'))); ?>

</div>
<?php else: ?>
<p class="category text-center m50">No Data Found</p>
<?php endif; ?>