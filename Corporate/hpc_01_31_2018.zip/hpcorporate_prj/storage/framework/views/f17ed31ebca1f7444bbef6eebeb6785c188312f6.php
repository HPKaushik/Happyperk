<?php $__env->startSection('page_title'); ?>
Company Locations
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header" data-background-color="purple">
                    <h4 class="title">All Company Locations <?php echo e($data->total()); ?></h4>
                    <div class="alert alert-yellow  pull-right" data-notify="container">
                        <a href='<?php echo e(URL::route('create-company-location')); ?>' class="">Add Location</a> 
                    </div>
                </div>
                <div class="card-content">
                    <div class="fresh-datatables ajax-table" id='corporate_list'>
                        <?php if($data->total() > 0): ?>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Actions</th>
                                    <th>Location Name</th>
                                    <th>Email</th>
                                    <th>Telephone</th>
                                    <th>Address</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="<?php echo e(URL::route('edit-company-location',$loc->id)); ?>">Edit</a></td>
                                    <td><?php echo e($loc->location_name); ?></td>
                                    <td><?php echo e($loc->email); ?></td>
                                    <td><?php echo e($loc->telephone); ?></td>
                                    <td><?php echo e($loc->address); ?></td>
                                </tr>                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($data->appends(Input::except('page'))); ?>

                        <?php else: ?>
                        <p class="category">No data Found</p>
                        <?php endif; ?>
                    </div> 
                </div> 
            </div> 
        </div> 
    </div> 
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>