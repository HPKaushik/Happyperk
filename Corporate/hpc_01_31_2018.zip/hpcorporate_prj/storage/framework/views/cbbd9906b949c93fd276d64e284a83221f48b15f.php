<?php if($data->total() > 0): ?>
<table class="table hover-table table-hover" >
    <thead >
        <tr>
            <th>User</th>
            <th>Operation</th>
            <th>On</th>
            <th>At</th>
            
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr >
            <td><?php echo e($l->module); ?>

            </td>
            <td >
            <span class="label label-<?php echo e($l->operation == 'Deleted' ? 'danger':'success'); ?>"><?php echo e($l->operation); ?></span>
              
            </td>
            <td><?php echo e(date('d M Y ',strtotime($l->created_at))); ?></td>
            <td><?php echo e(date('h:i:s a ',strtotime($l->created_at))); ?> &nbsp&nbsp<span style="color: gray"><?php echo e(\Carbon\Carbon::parse($l->created_at)->diffForHumans()); ?></span></td>
        
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="pagination">
    <?php echo e($data->appends(Input::except('page'))); ?>

</div>
<?php else: ?>
<p class="category">No Data Found</p>
<?php endif; ?>

