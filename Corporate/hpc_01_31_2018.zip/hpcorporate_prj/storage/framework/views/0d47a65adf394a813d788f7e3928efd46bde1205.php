<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
         <!-- <link rel="icon" type="image/x-icon" href="<?php echo e(asset('img/sweet.ico')); ?>"> -->
        <title> <?php echo $__env->yieldContent('page_title'); ?>- Happy Perks</title>
        <!-- Styles -->
        <?php echo $__env->make('inc.styles', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>
    <!--<body style="background:url('/img/sweets-bg2.jpg') no-repeat;background-size: cover;">-->
    <body>
       <div class="wrapper">
                <?php echo $__env->make('inc.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
               
            <div class="main-panel">
                 <?php echo $__env->make('inc.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('inc.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="content">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
            </div>
        </div>
        <?php echo $__env->make('inc.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('component_specific_js'); ?>
    </body>
</html>
