<?php $__env->startSection('page_title'); ?>
Manage Users
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header" data-background-color="blue">
                    <h4 class="title">All Users</h4>
                    <div class="alert alert-info pull-right" data-notify="container">
                        <a href='<?php echo e(URL::route('create-user')); ?>' class="">Add  User</a> 
                    </div>
                </div>
                <div class="card-content">
                    <!--                    <div class="header"  data-background-color="purple">
                                            <h3 class="box-title">Manage Users</h3>
                                            <?php if(Entrust::can('role-create')): ?>	        	
                                            <a class="btn btn-danger btn-fill btn-wd pull-right" href="<?php echo e(route('users.create')); ?>"> Create New User</a>
                                            <?php endif; ?>
                                        </div>-->

                    <div class="fresh-datatables">
                        <table class="table responsive-table" >
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Actions</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Roles</th>                								

                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user->id); ?></td>
                                    <td>
                                        <?php if(Entrust::can('role-edit')): ?>
                                        <a class="btn btn-simple btn-warning btn-icon edit" href="#"><i class="fa fa-edit"></i></a>&nbsp;
                                        <?php endif; ?>

                                    </td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td>
                                       <?php echo e($user->display_name); ?>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div> </div> </div> </div> </div> </div>

<?php $__env->stopSection(); ?>    

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>