<div class="sidebar" data-color="blue" data-image="../assets/img/sidebar-1.jpg">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | blue | green | orange | red"

        Tip 2: you can also add an image using data-image tag
    -->
            <div class="logo">
                <a href="#" class="hp-logo">
                  <img src="<?php echo e(asset('img/logo-white.png')); ?>" >
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="active">
                        <a href="<?php echo e(URL::route('dashboard')); ?>">
                            <i class="material-icons">dashboard</i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(URL::route('all-users')); ?>">
                            <i class="material-icons">person</i>
                            <p>Users</p>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="material-icons">content_paste</i>
                            <p>Attributes</p>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="material-icons">library_books</i>
                            <p>Categories</p>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="material-icons">bubble_chart</i>
                            <p>Products</p>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="material-icons">location_on</i>
                            <p>Sales</p>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="material-icons text-gray">notifications</i>
                            <p>Notifications</p>
                        </a>
                    </li>
                    <li class="">
                        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"> Logout </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;"><?php echo e(csrf_field()); ?></form>
                    </li>
                </ul>
            </div>
        </div>