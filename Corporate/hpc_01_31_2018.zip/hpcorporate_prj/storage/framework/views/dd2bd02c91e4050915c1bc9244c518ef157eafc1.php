<?php if($data->total() > 0): ?>
<table class="table hover-table table-hover" >
    <thead >
        <tr>
            <th>Actions</th>
            <th>Announcement Id</th>
            <th>Announcement Name</th>
            <th>Description</th>
            <th>Added On</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $anno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><a href="<?php echo e(URL::route('edit-announcement',$anno->id)); ?>">Edit</a></td>
            <td><?php echo e($anno->announcement_id); ?> </td>
            <td > <?php echo e($anno->name); ?></td>
            <td><?php echo e($anno->description); ?></td>
            <td><?php echo e(date('d M Y',strtotime($anno->created_at))); ?></td>
            <td><span class="label label-<?php echo e($anno->status == 0 ? 'danger':'success'); ?>"><?php echo e($anno->status == 0 ? 'InActive': 'Active'); ?></span></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="pagination">
    <?php echo e($data->appends(Input::except('page'))); ?>

</div>
<?php else: ?>
<p class="category">No Data Found</p>
<?php endif; ?>