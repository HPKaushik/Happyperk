<?php $__env->startSection('page_title'); ?>
Company Departments
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header" data-background-color="purple">
                    <h4 class="title">All Company Departments</h4>
                    <div class="alert alert-yellow  pull-right" data-notify="container">
                        <a href='<?php echo e(URL::route('create-company-department')); ?>' class="">Add Department</a> 
                    </div>
                </div>
                <div class="card-content">
                    <div class="fresh-datatables ajax-table" id='corporate_list'>
                        <?php if($data->total() > 0): ?>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Actions</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="<?php echo e(URL::route('edit-company-department',$dep->id)); ?>">Edit</a></td>
                                    <td><?php echo e($dep->department_name); ?></td>
                                    <td><?php echo e($dep->department_description); ?></td>
                                </tr>                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($data->appends(Input::except('page'))); ?>

                        <?php else: ?>
                        <p class="category">No data Found</p>
                        <?php endif; ?>
                    </div> 
                </div> 
            </div> 
        </div> 
    </div> 
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>