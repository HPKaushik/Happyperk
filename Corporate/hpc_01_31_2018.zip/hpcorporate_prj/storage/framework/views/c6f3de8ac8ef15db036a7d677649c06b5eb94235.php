<?php if($data->total() > 0): ?>
<table class="table hover-table table-hover" >
    <thead class="text-primary">
        <tr>
            <th><b>Transaction Id</b></th>
            <th><b>Initial Balance</b></th>
            <th><b>Credited</b></th>
            <th><b>Final Balance</b></th>
            <th><b>Credited On</b></th>
            <th><b>Status</b></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr >
            <td><?php echo e($tran->transaction_code); ?></td>
            <td><?php echo e($tran->begin_balance + 0); ?></td>
            <td><?php echo e($tran->credit_amount + 0); ?></td>
            <td><?php echo e($tran->end_balance + 0); ?></td>
            <td><?php echo e(date('d M Y', strtotime($tran->created_at))); ?> </td>
            <td><span class="label label-<?php echo e($tran->status == 'Completed' ? 'success':'danger'); ?>"><?php echo e($tran->status); ?></span></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="pagination">
    <?php echo e($data->appends(Input::except('page'))); ?>

</div>
<?php else: ?>
<p class="category">No Data Found</p>
<?php endif; ?>