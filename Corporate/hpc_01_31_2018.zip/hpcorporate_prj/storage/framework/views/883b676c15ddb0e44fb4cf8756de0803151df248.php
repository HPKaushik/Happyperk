<?php if($data->total() > 0): ?>
<table class="table hover-table table-hover" >
    <thead >
        <tr>
            <th><b>Id</b></th>
            <th><b>Award</b></th>
            <th><b>To</b></th>
            <th><b>Description</b></th>
            <th><b>On</b></th>
            <th><b>Status</b></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><a href="<?php echo e(URL::route('edit-award',$a->id)); ?>">Edit</a>
            </td>
            <td >
                <?php echo e($a->title); ?>

            </td>
            <td><?php echo e($a->first_name); ?>  <?php echo e($a->last_name); ?></td>
            <td><?php echo e($a->description); ?></td>
            <td><?php echo e(date('d M y', strtotime($a->created_at))); ?></td>
            <td><span class="label label-<?php echo e($a->status == 0 ? 'danger':'success'); ?>"><?php echo e($a->status == 0 ? 'InActive': 'Active'); ?></span></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="pagination">
    <?php echo e($data->appends(Input::except('page'))); ?>

</div>
<?php else: ?>
<p class="category">No Data Found</p>
<?php endif; ?>